# LethalLogger
 
LethalLogger is a mod for LethalCompany to write stats for rounds to a JSON file.
The intention is to have a companion R Script, and later python script to produce
graphs of common occurences, insight into player performances, causes of death,
and hopefully optimize strategies used by teams.
